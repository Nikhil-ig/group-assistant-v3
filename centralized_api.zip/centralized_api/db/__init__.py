"""
Initialize db module
"""

from .mongodb import ActionDatabase

__all__ = ["ActionDatabase"]
